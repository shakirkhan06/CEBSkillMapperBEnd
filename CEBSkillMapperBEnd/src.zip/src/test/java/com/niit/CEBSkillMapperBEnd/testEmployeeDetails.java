package com.niit.CEBSkillMapperBEnd;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.context.junit4.SpringRunner;
import com.niit.CEBSkillMapperBEnd.config.AppConfig;
import com.niit.CEBSkillMapperBEnd.model.EmployeeModel;
import com.niit.CEBSkillMapperBEnd.service.EmployeeService;

@RunWith(SpringRunner.class)
@SpringJUnitConfig(classes=AppConfig.class) 
public class testEmployeeDetails {
	
	@Autowired
	private EmployeeService employeeservice;
	
	EmployeeModel employeeemodel;
	@Before
	public void setUp() throws Exception 
	{
		employeeemodel=new EmployeeModel();
	}

	@After
	public void tearDown() throws Exception 
	{
		
	}

	@Test
	public void Adddata() 
	{
		employeeemodel.setEmpid(105);
		employeeemodel.setEmpname("Sardar");
		employeeemodel.setPassword("Khan");
		employeeemodel.setAge(25);
		employeeemodel.setGender("Male");
		employeeemodel.setAddress("Vellore");
		employeeemodel.setMobile(1234567890);
		employeeemodel.setEmail("Shakir@gmail.com");
		employeeemodel.setQualification("Msc");
		assertEquals("Success",true,employeeservice.addServe(employeeemodel));
	}
	
	@Test
	public void deletecheck()
	{
		assertEquals("not found",true,employeeservice.deleteServeById(101));
	}
	@Test
	public void Updatedata() 
	{
		employeeemodel.getEmpid(105);
		employeeemodel.setEmpname("Sardar");
		employeeemodel.setPassword("Khan");
		employeeemodel.setAge(25);
		employeeemodel.setGender("Male");
		employeeemodel.setAddress("Vellore");
		employeeemodel.setMobile(1234567890);
		employeeemodel.setEmail("Shakir@gmail.com");
		employeeemodel.setQualification("Msc");
		assertEquals("Success",true,employeeservice.updateServeById(employeeemodel));
	}
	/*@Test
	public void Selectdata() 
	{
		/*employeeemodel.getEmpid();
		employeeemodel.getEmpname();
		employeeemodel.getPassword();
		employeeemodel.getAge();
		employeeemodel.getGender();
		employeeemodel.getAddress();
		employeeemodel.getMobile();
		employeeemodel.getEmail();
		employeeemodel.getQualification();
		assertEquals("Success",true,employeeservice.selectServeById(102));
	}*/
}
