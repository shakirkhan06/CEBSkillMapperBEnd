package com.niit.CEBSkillMapperBEnd.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.CEBSkillMapperBEnd.dao.EmployeeDao;
import com.niit.CEBSkillMapperBEnd.model.EmployeeModel;
@Repository("employeedao")
@Transactional
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
    private SessionFactory sessionFactory;
	public List<EmployeeModel> getAllEmployeeDetails() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public EmployeeModel getEmployeeDetail(int empid) {
		// TODO Auto-generated method stub
		return (EmployeeModel) sessionFactory.getCurrentSession().createQuery("from EmployeeModel where empid="+empid).uniqueResult();
	}

	public boolean updateEmployeeDetail(EmployeeModel obj) {
         //return (EmployeeModel) sessionFactory.getCurrentSession().createQuery("from EmployeeModel where empid="+empid).uniqueResult();
		sessionFactory.getCurrentSession().update(obj);
		return true;
	}

	public boolean addEmployee(EmployeeModel obj) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(obj);
		return true;
	}
	public boolean deleteEmployee(int empid) {
		// TODO Auto-generated method stub
		EmployeeModel employeemodel=getEmployeeDetail(empid);
		if(employeemodel!=null)
		{
			sessionFactory.getCurrentSession().delete(employeemodel);
				return true;
		}
		else
			return false;
	}

	@Override
	public boolean updateEmployee(int empid) {
		return false;
		// TODO Auto-generated method stub
	}


	

}
