package com.niit.CEBSkillMapperBEnd.service;

import com.niit.CEBSkillMapperBEnd.model.EmployeeModel;

public interface EmployeeService {
	public boolean addServe(EmployeeModel employeemodel);
	  public boolean deleteServeById(int empid);
	  public EmployeeModel selectServeById(int empid);
	  public boolean updateServeById(EmployeeModel employeemodel);
}
