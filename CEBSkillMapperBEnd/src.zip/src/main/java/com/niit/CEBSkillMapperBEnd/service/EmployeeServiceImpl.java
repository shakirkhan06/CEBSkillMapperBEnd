package com.niit.CEBSkillMapperBEnd.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.CEBSkillMapperBEnd.dao.EmployeeDao;
import com.niit.CEBSkillMapperBEnd.model.EmployeeModel;
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeedao;
	public boolean addServe(EmployeeModel employeemodel) {
		// TODO Auto-generated method stub
		return (employeedao.addEmployee(employeemodel));	
	}
	public boolean deleteServeById(int empid) {
		// TODO Auto-generated method stub
		return (employeedao.deleteEmployee(empid));
	}
	public EmployeeModel selectServeById(int empid) {
		// TODO Auto-generated method stub
		return employeedao.getEmployeeDetail(empid);
	}
	@Override
	public boolean updateServeById(EmployeeModel employeemodel) {
		if(employeedao.getEmployeeDetail(employeemodel.getEmpid())!=null) {	
			employeedao.updateEmployeeDetail(employeemodel);
			return true;
		}
		else {
			return false;
		}
	}

}
