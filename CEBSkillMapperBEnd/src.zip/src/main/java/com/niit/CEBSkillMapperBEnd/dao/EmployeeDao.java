package com.niit.CEBSkillMapperBEnd.dao;

import java.util.List;

import com.niit.CEBSkillMapperBEnd.model.EmployeeModel;

public interface EmployeeDao 
{

	List<EmployeeModel> getAllEmployeeDetails();
	public EmployeeModel getEmployeeDetail(int empid);
	public boolean updateEmployeeDetail(EmployeeModel obj);
	public boolean updateEmployee(int empid);
	public boolean addEmployee(EmployeeModel obj);
	public boolean deleteEmployee(int empid);
}
